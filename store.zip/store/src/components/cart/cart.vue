<template>
	<div id="cart">
		<img src="../../../static/images/bg1.png" />
		<p>购物车空空，去逛逛吧</p>
		
		<router-link to='/index'><p>去逛逛
</p></router-link>
		
	</div>
</template>
<style scoped lang="less">
	#cart {
		text-align: center;
		margin-top: 0.4rem;
		img {
			margin-bottom: 0.3rem;
		}
		p {
			margin-bottom: 0.4rem;
			
		}
		
		a{
				background: #ffb400;
				display:block;
				height: 0.8rem;
			line-height: 0.8rem;
			width: 4rem;
			margin: 0 auto;
			
			color: #fff;
			}
	}
	
</style>