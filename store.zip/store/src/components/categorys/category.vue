<template>
	
	<div id="categoty" class="inlinkFlex">
		<div class="leftbar">
			<p class="barItem" :class="{active:bar === 'jksg'}" @click="onBar('jksg')">进口水果</p>
			<p class="barItem" :class="{active:bar === 'gcsg'}" @click="onBar('gcsg')">国产水果</p>
			<p class="barItem" :class="{active:bar === 'ggsc'}" @click="onBar('ggsc')">供港蔬菜</p>
			<p class="barItem" :class="{active:bar === 'dlp'}" @click="onBar('dlp')">蛋品类</p>
			<p class="barItem" :class="{active:bar === 'ylrl'}" @click="onBar('ylrl')">鱼类肉类</p>
			<p class="barItem" :class="{active:bar === 'yjzl'}" @click="onBar('yjzl')">有机杂粮</p>
			<p class="barItem" :class="{active:bar === 'jptl'}" @click="onBar('jptl')">精品调料</p>
			<p class="barItem" :class="{active:bar === 'lyfs'}" @click="onBar('lyfs')">粮油副食</p>
			<p class="barItem" :class="{active:bar === 'bmjp'}" @click="onBar('bmjp')">便民精品</p>
		</div>
		<div class="rightContent">
			<!--进口水果-->
			<div class="jksg" v-show="bar === 'jksg'">
				<div class="categoryItem inlinkFlex">
					<div class="shopImg">
						<img src="../../../static/images/bg1.png" />
					</div>
					<div class="shopText">
						<p>进口甜橙</p>
						<p>进口甜橙1234564</p>
						<p>¥19.80</p>
						<div class="cartOp inlinkFlex">
							<img src="../../../static/images/cut.png" alt="" />
							<input type="text" placeholder="0" />
							<img src="../../../static/images/add.png" alt="" />
						</div>
					</div>
				</div>
			</div>
			<!--国产水果-->
			<div class="jksg" v-show="bar === 'gcsg'">
				<div class="categoryItem inlinkFlex">
					<div class="shopImg">
						<img src="../../../static/images/bg1.png" />
					</div>
					<div class="shopText">
						<p>国产甜橙</p>
						<p>国产甜橙1234564</p>
						<p>¥19.80</p>
						<div class="cartOp inlinkFlex">
							<img src="../../../static/images/cut.png" alt="" />
							<input type="text" placeholder="0" />
							<img src="../../../static/images/add.png" alt="" />
						</div>
					</div>
				</div>
			</div>
		</div>
		<Footers></Footers>
	</div>
</template>
<style lang="less">
	@white: #fff;
	@grey: #ccc;
	#categoty{
		height: 100%;
		align-items: flex-start;
	}
	.leftbar{
		width: 2rem;
		height: 100%;
		background: #efefef;
		
	}
	.barItem{
			border-bottom: 1px solid #ccc;
			height: 0.88rem;
			line-height: 0.88rem;
		}
	.active.barItem{
		color:green;
		border-left: 4px solid green;
		background: @white;
	}
	.rightContent{
		flex: 1;
		
	}
	.categoryItem{
		padding: 0.1rem;
		border-bottom: 1px solid @grey;
	}
	.shopImg{
		width: 1.5rem;
		height: 2.2rem;
		margin-right: 0.2rem;
		img{
			width: 100%;
			height: 100%;
		}
	}
	.shopText{
		text-align: left;
		flex: 1;
		p{
			padding-bottom: 0.15rem;
		}
	}
	.cartOp{
			margin-top: 0.2rem;
			justify-content: flex-end;
			input{
				border:1px solid @grey;
				width: 0.4rem;
				height: 0.4rem;
				text-align: center;
				font-size: 0.2rem;
				margin-left: 0.1rem;
				margin-right: 0.1rem;
			}
			
		}
</style>
<script>
	import Footers from '../footer.vue';
	export default{
		data(){
			return{
				bar:'jksg'
			}
		},
		components: {
			Footers
		},
		methods:{
			onBar:function(item){
				const that = this;
				this.bar=item;
			}
		}
	}
</script>