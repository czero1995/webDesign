<template>
	<div id="member">
		<div class="top inlinkFlex">
			<img src="../../../static/images/bg1.png" />
			<p>凡几</p>
		</div>
		<router-link to='/address'>
			<div class="memberItem address inlinkFlex-spacebetween">
				<div class="itemChild">
					<img src="../../../static/images/add.png" />
					<span>收获地址</span>
				</div>			
				<img src="../../../static/images/cut.png" alt="" />
				
			</div>
		</router-link>
		<div class="memberItem itemList inlinkFlex-spacebetween">
			<div class="itemChild">
				<img src="../../../static/images/add.png" />
				<span>我的订单</span>
			</div>			
			<img src="../../../static/images/cut.png" alt="" />
			
		</div>
		<div class="memberItem itemList inlinkFlex-spacebetween">
			<div class="itemChild">
				<img src="../../../static/images/add.png" />
				<span>我的优惠卷</span>
			</div>			
			<img src="../../../static/images/cut.png" alt="" />
			
		</div>
		<router-link to="/collect">
			<div class="memberItem itemList inlinkFlex-spacebetween">			
					<div class="itemChild">
						<img src="../../../static/images/add.png" />
						<span>我的收藏</span>
					</div>			
				<img src="../../../static/images/cut.png" alt="" />			
			</div>
		</router-link>
		<Footers></Footers>
	</div>
	
</template>
<style scoped lang="less">
	@white:#fff;
	@grey:#ccc;
	#member{
		background: #efefef;
		height: 100%;
	}
	.top{
		height: 1.2rem;
		background: @white;
		padding: 0.2rem 0.4rem 0.4rem 0.2rem;
		margin-bottom: 0.2rem;
		img{
			border-radius: 1rem;
			height: 0.8rem;
			width: 0.8rem;
			margin-right: 0.2rem;
		}
		p{
			font-size: 0.3rem;
		}
	}
	.memberItem{
		height: 1rem;
		line-height: 1rem;
		background: @white;
		padding: 0rem 0.4rem 0rem 0.2rem;
	}
	
	.itemChild img{
		margin-right: 0.2rem;
		vertical-align: middle;
	}
	.address{
		margin-bottom: 0.2rem;
	}
	.itemList{
		border-bottom: 1px solid @grey;
	}
</style>
<script>
	import Footers from '../footer.vue'
	export default{
		data(){
			return{
				
			}
		},
		components:{
			Footers
		}
	}
</script>