<template>
	<div id="address">
		<div class="top inlinkFlex">
			<img src="../../../static/images/add.png" alt="" />
			<p>添加新地址</p>	
		</div>
		<div class="addressItem inlinkFlex">
			<p>所在地区</p>
			<input type="text" placeholder="广东省 深圳市 龙华新区"  readonly/>
			<img src="../../../static/images/add.png" />
		</div>
		<div class="addressItem inlinkFlex">
			<p>详细地址</p>
			<input type="text" placeholder="请输入到小区门牌号码"  readonly/>
		</div>
		<div class="addressItem inlinkFlex">
			<p>收货人姓名</p>
			<input type="text" placeholder="收货人姓名"  readonly/>
		</div>
		<div class="addressItem inlinkFlex">
			<p>手机号码</p>
			<input type="text" placeholder="收货人常用手机号码"  readonly/>
		</div>
		<p class="save">
			保存
		</p>
	</div>
</router-link>
		
	</div>
</template>
<style scoped lang="less">
	#address{
		background: #EFEFEF;
		height: 100%;
	}
	.top{
		height: 0.8rem;
		background: green;
		line-height: 0.8rem;
		font-size: 0.36rem;
		color:#fff;
		text-align: center;
		padding-left: 0.3rem;
		
		p{
			width: 100%;
		}
		
	}
	.addressItem{
		border-bottom: 1px solid #ccc;
		padding-left: 0.3rem;
		height: 0.88rem;
		line-height: 0.88rem;
		background: #fff;
		p{
			margin-right: 0.4rem;
		}
		input{
			font-size: 0.26rem;
			width: 3rem;
		}
		img{
			margin-left: 1.4rem;
		}
	}
	.save{
		
		height: 0.8rem;
		line-height: 0.8rem;
		color:#FFFFFF;
		width: 90%;
		text-align: center;
		background: #ffb400;
		margin: 0 auto;
		margin-top: 0.8rem;
	}
</style>