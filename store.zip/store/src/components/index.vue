<template>
	<div id="index">
		<div class="header inlinkFlex">
			<img src="../../static/images/add.png" />
			<p class="address">深圳市</p>
			<p>火夫100为您服务</p>
		</div>
		<div class="top inlinkFlex-around">
			<div class="top-item">
				<img src="../../static/images/bg1.png"  />
				<p>订单</p>
			</div>
			<div class="top-item">
				<img src="../../static/images/bg1.png"  />
				<p>优惠券</p>
			</div>
			<div class="top-item">
				<img src="../../static/images/bg1.png"  />
				<p>秒杀专场</p>
			</div>
		</div>
		<div class="productTop inlinkFlex">
			<img src="../../static/images/star-half.png" />
			<p>下午茶</p>
		</div>
		<div class="productBox inlinkFlex-spacebetween">
			
				<div class="productItem inlinkFlex">
					
					<div class="itemBox">
						<router-link to='detail'>
						<img src="../../static/images/bg1.png"  class="itemImg"/>
						<div class="itemText">
							<p>进口红提</p>
							<p class="itemIntro">进口红提进口红提进口红提进口红提进口红提进口红提进口红提进口红提进口红提</p>
							<p><span>26.60</span>元</p>
						</div>
						</router-link>
						<div class="cartOp inlinkFlex">
							<img src="../../static/images/cut.png" @click.stop="onCutCart" />
							<input type="text"  :value="cartNum"/>
							<img src="../../static/images/add.png" @click.stop="onAddCart" />
						</div>
						
					</div>
					
				</div> 
			
			<div class="productItem inlinkFlex">
			<div class="itemBox">
				<img src="../../static/images/bg1.png"  />
				<div class="itemText">
					<p>进口红提</p>
					<p class="itemIntro">进口红提进口红提进口红提进口红提</p>
					<p>26.60元</p>
				</div>
				<div class="cartOp inlinkFlex">
					<img src="../../static/images/cut.png" alt="" />
					<input type="text" placeholder="0" />
					<img src="../../static/images/add.png" alt="" />
				</div>
			</div>
		</div> 
		</div>
		<div class="productTop inlinkFlex">
			<img src="../../static/images/star-half.png" />
			<p>进口水果</p>
		</div>
		<div class="productBox inlinkFlex-spacebetween">
			<div class="productItem inlinkFlex" >
				
					<div class="itemBox">
						<img src="../../static/images/bg1.png"  class="itemImg"/>
						<div class="itemText">
							<p>进口红提</p>
							<p class="itemIntro">进口红提进口红提进口红提进口红提进口红提进口红提进口红提进口红提进口红提</p>
							<p>26.60元</p>
						</div>
						<div class="cartOp inlinkFlex">
							<img src="../../static/images/cut.png" alt="" />
							<input type="text" placeholder="0" />
							<img src="../../static/images/add.png" alt="" />
						</div>
					</div>
			
			</div> 
			<div class="productItem inlinkFlex">
			<div class="itemBox">
				<img src="../../static/images/bg1.png"  />
				<div class="itemText">
					<p>进口红提</p>
					<p class="itemIntro">进口红提进口红提进口红提进口红提</p>
					<p>26.60元</p>
				</div>
				<div class="cartOp inlinkFlex">
					<img src="../../static/images/cut.png" alt="" />
					<input type="text" placeholder="0" />
					<img src="../../static/images/add.png" alt="" />
				</div>
			</div>
		</div> 
		</div>
		<div class="productTop inlinkFlex">
			<img src="../../static/images/star-half.png" />
			<p>国产水果</p>
		</div>
		<div class="productBox inlinkFlex-spacebetween">
			<div class="productItem inlinkFlex">
				<div class="itemBox">
					<img src="../../static/images/bg1.png"  class="itemImg"/>
					<div class="itemText">
						<p>进口红提</p>
						<p class="itemIntro">进口红提进口红提进口红提进口红提进口红提进口红提进口红提进口红提进口红提</p>
						<p>26.60元</p>
					</div>
					<div class="cartOp inlinkFlex">
						<img src="../../static/images/cut.png" alt="" />
						<input type="text" placeholder="0" />
						<img src="../../static/images/add.png" alt="" />
					</div>
				</div>
			</div> 
			<div class="productItem inlinkFlex">
			<div class="itemBox">
				<img src="../../static/images/bg1.png"  />
				<div class="itemText">
					<p>进口红提</p>
					<p class="itemIntro">进口红提进口红提进口红提进口红提</p>
					<p>26.60元</p>
				</div>
				<div class="cartOp inlinkFlex">
					<img src="../../static/images/cut.png" alt="" />
					<input type="text" placeholder="0" />
					<img src="../../static/images/add.png" alt="" />
				</div>
			</div>
		</div> 
		</div>
	<Footers></Footers>
	</div>
	
</template>
<style scoped lang="less">
	@white: #fff;
	@grey: #ccc;
	#index{
		background: #efefef;
		height: 100%
	}
	.header{
		background: green;
		color:@white;
		font-size: 0.;
		height: 0.8rem;
		padding-left: 0.3rem;
		img{
			margin-right: 0.2rem;
		}
		
	}
	.address{
		margin-right: 0.2rem;
		color:@white;

	}
	.top{
		padding-top: 0.3rem;
		background: @white;
	}
	.top-item{
		p{	
			margin-top: 10px;
			
		}
		
	}
	.productTop{
		padding-left: 10px;
		margin-top: 10px;
		margin-bottom: 10px;
		height: 0.6rem;
		background: @white;
		img{
			margin-right: 10px;
			
		}
	}

	.productItem{
		width: 44%;	
		padding:0.2rem;
		background: @white;	
		.itemBox{			
		    width: 100%;
		}	    
		.itemText{
			margin-top: 0.1rem;
			text-align: left;
			width: 100%; 
			 white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
			
			
		}
		.itemIntro{
			margin-top: 0.15rem;
			margin-bottom: 0.15rem;	
		
				    				   
		}
		.cartOp{
			margin-top: 0.2rem;
			justify-content: flex-end;
			input{
				border:1px solid @grey;
				width: 0.4rem;
				height: 0.4rem;
				text-align: center;
				font-size: 0.2rem;
				margin-left: 0.1rem;
				margin-right: 0.1rem;
			}
			
		}
	}

</style>
<script type="text/javascript">
	import Footers from './footer.vue';
	export default{
		data(){
			return{
				cartNum:'0',
				allCoach:'0',
			}
		},
		components: {
			Footers
		},
		methods:{
			onAddCart(){
				const that = this;
				that.cartNum ++ ;
				console.log(that.cartNum)
			},
			onCutCart(){
				const that = this;
				if(that.cartNum > 0){
					that.cartNum -- ;
				}
				
				
			},
		}
	}
</script>