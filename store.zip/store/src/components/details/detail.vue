<template>
	<div id="detail">
		<div class="circul">
			
		</div>
		<div class="shopTop">
			<p class="shopName">进口无子红提</p>
			<p class="shopCoach">¥26.60</p>
			<div class="inlinkFlex-spacebetween">
				<p>已售50件</p>
				<p>收藏3人</p>
				<p>满38元免运费</p>
			</div>
			
		</div>
		<div class="shopCenter">
			<div class="shop-num">
				<p>数量</p>
				<div class="cartOp inlinkFlex">
							<img src="../../../static/images/cut.png" alt="" />
							<input type="text" placeholder="0" />
							<img src="../../../static/images/add.png" alt="" />
				</div>
			</div>
			<div>重量(1x500-600g)</div>
		</div>
		<div class="shopBottom inlinkFlex-around">
			
			<div><img src="../../../static/images/add.png"  /></div>
			<div><img src="../../../static/images/add.png"  /></div>
			<div><img src="../../../static/images/add.png"  /></div>
			<div class="addCart">加入购物车</div>
		</div>
	</div>
</template>
<style scoped lang="less">
	@white:#fff;
	@grey: #ccc;
	#detail{
		background: #ebebeb;
		
	}
	.circul{
		height: 3rem;
	}
	.shopTop{
		background: @white;
		padding: 0.5rem 0.3rem;
		margin-bottom: 0.2rem;
	}
	.shopName{
		font-size: 0.4rem;
		margin-bottom: 0.3rem;
	}
	.shopCoach{
		color:#98d13e;
		font-size: 0.4rem;
		margin-bottom: 0.3rem;
	}
	.shopCenter{
		background: @white;
		text-align: left;
		padding: 0 0.3rem;
		div{
			height: 1.4rem;
			line-height: 1.4rem;
			border-bottom: 1px solid @grey;
		}
	}
	.shopBottom{
		width: 100%;
		text-align: center;
		position: fixed;
		
		height: 0.88rem;
		border-top: 1px solid @grey;
		bottom: 0;
		
		div{
			text-align: center;
			width: 22%;
		}
		.addCart{
		background: red;
		color:@white;
		width: 34%;
		height: 100%;
		margin-left: 0.2rem;
		line-height: 0.88rem;
	}
	}
	.cartOp{
			justify-content: flex-end;
			input{
				width: 0.4rem;
				text-align: center;
				font-size: 0.2rem;
				margin-left: 0.1rem;
				margin-right: 0.1rem;
				border: none;
			}
			
		}
	
</style>