<template>
	<div id="activity">
		<p>123</p>
		<Footers></Footers>
	</div>
</template>
<script>
	import Footers from '../footer.vue'
	export default{
		data(){
			return{
				
			}
		},
		components:{
			Footers
		}
	}
</script>