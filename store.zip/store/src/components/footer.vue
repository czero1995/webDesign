<template>
	<div id="footer">
	<div class="footerBox">

		<router-link to='/index'>首页</router-link>
		<router-link to='/category'>分类</router-link>
		
		<router-link to='/activity'>活动</router-link>
		<router-link to='/member'>我的</router-link>
	</div>
	<router-link to='/cart'>
		<div class="cart">
			<img  src="../assets/logo.png" />
			<p>总价:{{allCoach}}</p>
		</div>
	</router-link>
	
</div>
</template>

<style scoped lang="less">
	#footer {
		height: 0.88rem;
		border-top: 1px solid #ccc;
		align-items: center;
		font-size: 0.28rem;
		position: fixed;
		bottom: 0;
		width: 100%;
		background: #fff;
		
	}
	
	.footerBox {
		height: 0.88rem;
		width: 100%;
		display: flex;
		justify-content: space-around;
		align-items: center;
		text-align: center;
	}
	.cart{
		
		height: 0.4rem;
		position:absolute;
		top: -0.2rem;
		left: 0;
		right: 0;
		margin: auto;
		img{
			height: 0.8rem;
			width: 0.8rem;
		}
		
		p{
			color: #fff;
			background: green;
			position: absolute;
			border-radius: 0.1rem;
			top: -0.3rem;
			left: 52%;		
			padding-left: 0.1rem;
			padding-right: 0.1rem;
		}
	}
	
</style>
<script>
	export default{
		data(){
			return{
				allCoach:'0'
			}
		}
	}
</script>