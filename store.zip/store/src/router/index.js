import Vue from 'vue'
import Router from 'vue-router'
import index from '@/components/index'
import category from '@/components/categorys/category'
import activity from '@/components/activitys/activity'
import member from '@/components/members/member'
import detail from '@/components/details/detail'
import cart from '@/components/cart/cart'
import address from '@/components/members/address'
import collect from '@/components/members/collect'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',   
      component: index
    },
    {
    	path:'/index',
    	component: index
    },
    {
    	path:'/category',
    	component: category
    },
    {
    	path:'/activity',
    	component: activity
    },
    {
    	path:'/member',
    	component: member
    },
    {
    	path:'/detail',
    	component: detail
    },
     {
    	path:'/cart',
    	component: cart
    },
    {
    	path:'/address',
    	component: address
    },
    {
    	path:'/collect',
    	component: collect
    },
  ]
})
