<template>
	
	  <div id="app"> 
	  	<div id="mainContent">
	    	<router-view></router-view>
	   </div>
	    
	  </div>  
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
body,html{
	height: 100%;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  display: flex;
  flex-direction: column;
  height: 100%;
  font-size: 0.24rem;
 
}
#mainContent{
	flex: 1;
	padding-bottom: ;: 0.88rem;
}


</style>
